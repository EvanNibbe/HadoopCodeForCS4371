/*
Evan Nibbe
Big data hadoop
Project 2
MutualFriends is a class that works within the hadoop environment that takes as input a file with
a list of userIDs separated with one user followed by tab followed by a comma-separated list of the userIDs of the friends of that user
*/
//The following are the import statements recommended in the hadoop.apache.org/docs/current/hadoop-mapreduce... webpage
import java.io.IOException;
import java.util.*; //includes ArrayList and its parents.
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class MutualFriends {
	public static String rmNonDigit(String input) {
		String result="";
		char v='\0';
		boolean seenNum=false;
		for (int i=0; i<input.length() && (!seenNum || (v<='9' && v>='0')); i++) {
			v=input.charAt(i);
			if (v<='9' && v>='0') {
				result+=""+v;
				seenNum=true;
			}
		}
		return result;
	}
	public static ArrayList<String> splitNum(String input) {
		ArrayList<String> result=new ArrayList<>();
		String temp="";
		char v='\0';
		boolean seenNum=false;
		for (int i=0; i<input.length() /*&& (!seenNum || (v<='9' && v>='0'))*/; i++) {
			v=input.charAt(i);
			if (v<='9' && v>='0') {
				temp+=""+v;
				seenNum=true;
			} else if (temp.length()>0 && seenNum) {
				result.add(temp);
				temp="";
				seenNum=false;
			}
		}
		return result;
	}
	public static class TokenizerMapper extends Mapper<Object, Text, Text, Text>{
		//private final static IntWritable one =new IntWritable(1);
		private Text word =new Text();
		private Text newValue=new Text();
		public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
			//StringTokenizer itr=new StringTokenizer(value.toString());
			String[] lines=value.toString().split("\n");
			for (String line : lines) {
				ArrayList<String> friendStrings=splitNum(line);//line.split(",");
				String word1=rmNonDigit(friendStrings.get(0));
				int i=line.indexOf("\t");
				if (i>0 && i<line.length()-1) {
					;
				} else {
					continue;
				}
				//String remaining=line.substring(i+1, line.length()-1);
				for (int j=1; j<friendStrings.size(); j++) {
					String word2=friendStrings.get(j);//.trim(); //remove whiitespace on sides.
					String key2="";
					String which2, which1;
					if (word2.length()<1) {
                                                continue; //skip
                                        }
					if (word1.compareTo(word2)>0) {
						which2="l"; //rather than 1 and 0 since those are user ids
						which1="o";
						key2=word1+","+word2;
					} else {
						which2="o";
						which1="l";
						key2=word2+","+word1; //we have to make sure that keys for the same two user names must look the same
						//the which1 string is the first in the ArrayList in order to tell the reducer which of the two members of the 
						//key is the one whose friends those are
					}
					/*
					ArrayList<String> friends=new ArrayList<>();
					friends.add(which1);
					for (int k=0; k<friendStrings.length; k++) {
						if (k!=j) {
							friends.add(rmNonDigit(friendStrings[k]));
						}
					}
					*/
					try {
						word.set(key2);
						String newValueStr="";
						for (int r=0; r< friendStrings.size(); r++) {
							if (r==friendStrings.size()-1) {
										newValueStr+=friendStrings.get(r);
							} else {
								newValueStr+=friendStrings.get(r)+",";
							}
						}
						newValue.set(newValueStr);
						context.write(word, newValue);
					} finally {
						;
					}
				}
				//if (itr.hasMoreTokens()) {
				//	word.set(itr.nextToken());
				//}
			
				//context.write(word, friends);
			}
		}
	}
	public static class IntSumReducer extends Reducer<Text, Text, Text, Text> {
		//private IntWritable result=new IntWritable();
		private Text result=new Text();
		public void reduce(Text key1, Iterable<Text> valuesOrig, Context context) throws IOException, InterruptedException {
			String key=key1.toString();
			String[] baseWords=key.split(",");
			if (baseWords.length!=2) {
				return ;
			}
			ArrayList<ArrayList<String>> values=new ArrayList<>();
			int pieces=0;
			for (Text dividecomma : valuesOrig) {
				pieces++;
				String[] temp=dividecomma.toString().split(",");
				ArrayList<String> temp2=new ArrayList<>();
				for (String otherTemp : temp) {
					temp2.add(otherTemp);
				}
				values.add(temp2);
			}
			if (pieces<2) {
				//result.set("Less than 2 in list: "+values.toString()+valuesOrig.toString());
				//context.write(key1, result);
				return ; //skip for insufficient information.
			}
			//int sum=0;
			//for (IntWritable val : values) {
			//	sum+=val.get();
			//}
			//result.set(sum);
			//context.write(key, result);
			ArrayList<String> first=new ArrayList<>();
			ArrayList<String> combined=new ArrayList<String>();
			String whichFirst=""; //either "0" or "1" //changed to o and l respectively
			int seenFirst=0; //set to 1 once first has passed.
			for (ArrayList<String> friends1 : values) {
				if (seenFirst==0) {
					seenFirst=1;
					first=friends1;
					whichFirst=friends1.get(0);
				} else { //now the loop that involves getting rid of repeats
					if (friends1.get(0).charAt(0)==whichFirst.charAt(0)) { //these are the same user, so skip
						continue;
					}
					for (int i=1; i<friends1.size(); i++) { //potmut : friends1) { //this skips the 1 or 0 at the front.
						if (friends1.get(i).compareTo(baseWords[0])!=0 && friends1.get(i).compareTo(baseWords[1])!=0 && first.contains(friends1.get(i))) {
							//make sure that the mutual friends are not themselves.
							combined.add(friends1.get(i));
							first.remove(friends1.get(i)); //prevents this from showing up again.
						}
					}
				}
			}
			if (combined.size()>0) {
			try {
				String resultStr="";//"mutual frineds:"+values.get(0).size()+","+values.get(1).size()+","+combined.size()+"\t";
				for (int i=0; i<combined.size(); i++) {
					if (i==combined.size()-1) {
						resultStr=resultStr+combined.get(i);
					} else {
						resultStr=resultStr+combined.get(i)+",";
					}
				}
				//resultStr=resultStr+">";
				result.set(resultStr);
				context.write(key1, result);
			} finally {
				;
			}
			}
		}
	}
	public static void main(String[] args) throws Exception {
		Configuration conf=new Configuration();
		Job job=Job.getInstance(conf, "Mutual Friends");
		job.setJarByClass(MutualFriends.class);
		job.setMapperClass(TokenizerMapper.class);
		//job.setCombinerClass(IntSumReducer.class);
		job.setReducerClass(IntSumReducer.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);
		for (String arg : args) System.out.printf("%s\t", arg);
		System.out.println(" ");
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		System.exit(job.waitForCompletion(true)? 0 : 1);
	}
}
