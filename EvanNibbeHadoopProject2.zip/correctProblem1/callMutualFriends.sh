#!/bin/bash
hadoop com.sun.tools.javac.Main MutualFriends.java
jar cf MutualFriends.jar MutualFriends*.class
hdfs dfs -rm MutualFriends.jar
hdfs dfs -rm -f -R outputMutualFriends
hdfs dfs -put MutualFriends.jar
hadoop jar MutualFriends.jar MutualFriends inputMutualFriends outputMutualFriends
