#!/bin/bash
hadoop com.sun.tools.javac.Main AvgAndVarianceFriends.java
jar cf AvgAndVarianceFriends.jar AvgAndVarianceFriends*.class
hdfs dfs -rm AvgAndVarianceFriends.jar
hdfs dfs -rm -f -R outputAvgAndVariance
hdfs dfs -put AvgAndVarianceFriends.jar
hadoop jar AvgAndVarianceFriends.jar AvgAndVarianceFriends inputMutualFriends outputAvgAndVariance
