/*
Evan Nibbe
Big data hadoop
Project 2
AvgAndVarianceFriends is a class that works within the hadoop environment that takes as input a file with
a list of userIDs separated with one user followed by tab followed by a comma-separated list of the userIDs of the friends of that user
It outputs two numbers: the mean of the number of friends, and the variance of the number of friends.
*/
//The following are the import statements recommended in the hadoop.apache.org/docs/current/hadoop-mapreduce... webpage
import java.io.IOException;
import java.util.*; //includes ArrayList and its parents.
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class AvgAndVarianceFriends {
	public static String rmNonDigit(String input) {
		String result="";
		char v='\0';
		boolean seenNum=false;
		for (int i=0; i<input.length() && (!seenNum || (v<='9' && v>='0')); i++) {
			v=input.charAt(i);
			if (v<='9' && v>='0') {
				result+=""+v;
				seenNum=true;
			}
		}
		return result;
	}
	public static ArrayList<Double> splitNum(String input) {
		ArrayList<Double> result=new ArrayList<>();
		char v='\0';
		boolean seenNum=false;
		boolean seenPeriod=false;
		double divisor=10;
		for (int i=0; i<input.length() /*&& (!seenNum || (v<='9' && v>='0'))*/; i++) {
			v=input.charAt(i);
			if (v<='9' && v>='0' && !seenNum) {
				seenNum=true;
				double initial=v-'0';
				if (i>0 && input.charAt(i-1)=='.') {
					if (i>1 && input.charAt(i-2)=='-') {
						initial*=-1;
					}
					seenPeriod=true;
					initial/=10.0;
				} else if (i>0 && input.charAt(i-1)=='-') {
					initial*=-1;
				}
				result.add(new Double(initial));
			} else if (v<='9' && v>='0') {
				double temp=result.get(result.size()-1); //auto unboxing
				double temp2=v-'0';
				if (seenPeriod) {
					temp2/=divisor;
					divisor*=10.0;
				} else {
					temp*=10;
				}
				result.set(result.size()-1, new Double(temp+temp2));
				seenNum=true;
			} else if (v=='.') {
				seenPeriod=true;
				divisor=10;
			} else if (seenNum) {
				seenPeriod=false;
				seenNum=false;
			}
		}
		return result;
	}
	public static int getNum(String input) {
		int result=0;
		for (int i=0; i<input.length(); i++) {
			char v=input.charAt(i);
			if (v<='9' && v>='0') {
				result*=10;
				result+=v-'0';
			}
		}
		return result;
	}
	public static String putNum(int input) {
		return ""+input;
	} 
	public static String putNum(double input) {
		return ""+input;
	}
	public static double newVariance(double curvar, double curmean, double allsum, int count, double newmean) {
		//resoved sum((ui-mean)^2 for i=1 to n) to sum(ui^2 for i=1 to n)-2*mean*sum(ui from i=1 to n)+n*mean^2 using algebra
		return curvar+2*curmean*allsum-count*curmean*curmean-2*newmean*allsum+count*newmean*newmean;
	}
	public static class TokenizerMapper extends Mapper<Object, Text, Text, Text>{
		//private static final IntWritable one =new IntWritable(1);
		private Text word =new Text();
		private Text newValue=new Text();
		public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
			//StringTokenizer itr=new StringTokenizer(value.toString());
			String[] lines=value.toString().split("\n");
			int count=lines.length; 
			double friends=0; 
			int index=0;
			int[] numFriends=new int[count]; //number of friends per person
			for (String line : lines) {
				ArrayList<Double> friendStrings=splitNum(line);//line.split(",");
				int i=line.indexOf("\t");
				if (i>0 && i<line.length()-1) {
					;
				} else {
					continue;
				}
				friends+=friendStrings.size()-1; //the first number is the person who has friends.
				numFriends[index]=friendStrings.size()-1;
				index++;
			}
			try {
				word.set(" "); //eerything is going into the same reducer
				String newValueStr="";
				double mean=friends/(0.0+count);
				double variance=0;
				for (int r=0; r< count; r++) {
					double temp=numFriends[r]-mean;
					variance+=temp*temp;
				}
				newValueStr=""+friends+"\t"+count+"\t"+variance;
				newValue.set(newValueStr);
				context.write(word, newValue);
			} finally {
				;
			}
		}
	}
	public static class IntSumReducer extends Reducer<Text, Text, Text, Text> {
		//private IntWritable result=new IntWritable();
		private Text result=new Text();
		public void reduce(Text key1, Iterable<Text> valuesOrig, Context context) throws IOException, InterruptedException {
			ArrayList<ArrayList<Double>> values=new ArrayList<>();
			int pieces=0;
			double count=0; //just numbers among integers.
			double friends=0;
			double variance=0;
			for (Text dividecomma : valuesOrig) {
				pieces++;
				ArrayList<Double> temp=splitNum(dividecomma.toString());
				values.add(temp);
				friends+=temp.get(0);
				count+=temp.get(1);
			}
			for (ArrayList<Double> temp : values) {
				variance+=newVariance(temp.get(2).doubleValue(), (temp.get(0).doubleValue()/temp.get(1).doubleValue()), temp.get(0).doubleValue(), temp.get(1).intValue(), friends/count);
			}
			try {
				String resultStr=""+(friends/count)+"\t"+variance;
				//resultStr=resultStr+">";
				result.set(resultStr);
				context.write(key1, result);
			} finally {
				;
			}
		}
	}
	public static void main(String[] args) throws Exception {
		Configuration conf=new Configuration();
		Job job=Job.getInstance(conf, "AvgAndVarianceFriends");
		job.setJarByClass(AvgAndVarianceFriends.class);
		job.setMapperClass(TokenizerMapper.class);
		//job.setCombinerClass(IntSumReducer.class);
		job.setReducerClass(IntSumReducer.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);
		for (String arg : args) System.out.printf("%s\t", arg);
		System.out.println(" ");
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		System.exit(job.waitForCompletion(true)? 0 : 1);
	}
}
