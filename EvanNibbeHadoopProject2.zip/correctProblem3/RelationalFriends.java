/*
Evan Nibbe
Big data hadoop
Project 2
RelationalFriends is a class that works within the hadoop environment that takes as input a file with
a list of userIDs separated with one user followed by tab followed by a comma-separated list of the userIDs of the friends of that user
and a file with columns of
userid, firstname, lastname, address, city, state, zipcode, country, username, data of birth
It outputs:
(If last argument is A)
SELECT userid, firstname, city FROM userdata.txt
(If last argument is B)
SELECT userid, firstname, city FROM userdata.txt WHERE State="New York"
(if last argument is C)
SELECT state, COUNT(*) FROM userdata.txt GROUP BY state
(if last argument is D)
SELECT state, COUNT(*) FROM userdata.txt WHERE YEAR(dateOfBirth)>=1970 GROUP BY state
(if last argument is E)
(using a table created by a join on userid between userdata.txt and soc-LiveJournal1Adj.txt) output userid, first name, city and number of friends for the user (repeat for all users)
*/
//The following are the import statements recommended in the hadoop.apache.org/docs/current/hadoop-mapreduce... webpage
import java.io.IOException;
import java.util.*; //includes ArrayList and its parents.
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class RelationalFriends {
	public static String rmNonDigit(String input) {
		String result="";
		char v='\0';
		boolean seenNum=false;
		for (int i=0; i<input.length() && (!seenNum || (v<='9' && v>='0')); i++) {
			v=input.charAt(i);
			if (v<='9' && v>='0') {
				result+=""+v;
				seenNum=true;
			}
		}
		return result;
	}
	public static ArrayList<Double> splitNum(String input) {
		ArrayList<Double> result=new ArrayList<>();
		char v='\0';
		boolean seenNum=false;
		boolean seenPeriod=false;
		double divisor=10;
		for (int i=0; i<input.length() /*&& (!seenNum || (v<='9' && v>='0'))*/; i++) {
			v=input.charAt(i);
			if (v<='9' && v>='0' && !seenNum) {
				seenNum=true;
				double initial=v-'0';
				if (i>0 && input.charAt(i-1)=='.') {
					if (i>1 && input.charAt(i-2)=='-') {
						initial*=-1;
					}
					seenPeriod=true;
					initial/=10.0;
				} else if (i>0 && input.charAt(i-1)=='-') {
					initial*=-1;
				}
				result.add(new Double(initial));
			} else if (v<='9' && v>='0') {
				double temp=result.get(result.size()-1); //auto unboxing
				double temp2=v-'0';
				if (seenPeriod) {
					temp2/=divisor;
					divisor*=10.0;
				} else {
					temp*=10;
				}
				result.set(result.size()-1, new Double(temp+temp2));
				seenNum=true;
			} else if (v=='.') {
				seenPeriod=true;
				divisor=10;
			} else if (seenNum) {
				seenPeriod=false;
				seenNum=false;
			}
		}
		return result;
	}
	public static int getNum(String input) {
		int result=0;
		for (int i=0; i<input.length(); i++) {
			char v=input.charAt(i);
			if (v<='9' && v>='0') {
				result*=10;
				result+=v-'0';
			}
		}
		return result;
	}
	public static String putNum(int input) {
		return ""+input;
	} 
	public static String putNum(double input) {
		return ""+input;
	}
	public static class TokenizerMapper extends Mapper<Object, Text, Text, Text>{ //for the A operation
		//private static final IntWritable one =new IntWritable(1);
		private Text word =new Text();
		private Text newValue=new Text();
		public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
			//StringTokenizer itr=new StringTokenizer(value.toString());
			String[] lines=value.toString().split("\n");
			boolean proper=true; //make sure this is the right file
			for (String line : lines) {
				if (line.length()<3) {
					continue;
				}
				String[] fields=line.split(",");
				if (!(fields.length==1) && (fields.length!=10 || (fields.length<6 || (fields[5].length()==0 || (fields[5].charAt(0)>='0' && fields[5].charAt(0)<='9'))))) { //the 5th element in the userdata file's rows is state, which is non-numeric
					proper=false;
					break; //do not go forward with this document.
				}
				if (fields.length==10) {
					;
				} else {
					continue;
				}
				String value1=fields[1]+","+fields[4]; //SELECT userid, firstname, city
				word.set(fields[0]); //userid from above
				newValue.set(value1);
				try {
					context.write(word, newValue);
				} finally {
					;
				}
				
			}
		}
	}
	public static class BTokenizerMapper extends Mapper<Object, Text, Text, Text>{ //for the B operation
		//private static final IntWritable one =new IntWritable(1);
		private Text word =new Text();
		private Text newValue=new Text();
		public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
			//StringTokenizer itr=new StringTokenizer(value.toString());
			String[] lines=value.toString().split("\n");
			boolean proper=true; //make sure this is the right file
			for (String line : lines) {
				if (line.length()<3) {
					continue;
				}
				String[] fields=line.split(",");
				if (!(fields.length==1) && (fields.length!=10 || (fields.length<6 || (fields[5].length()==0 || (fields[5].charAt(0)>='0' && fields[5].charAt(0)<='9'))))) { //the 5th element in the userdata file's rows is state, which is non-numeric
					proper=false;
					break; //do not go forward with this document.
				}
				if (fields.length==10 && fields[5].compareTo("New York")==0) {
					;
				} else {
					continue; //skip if not a line or not in New York
				}
				String value1=fields[1]+","+fields[4]; //SELECT userid, firstname, city
				word.set(fields[0]); //userid from above
				newValue.set(value1);
				try {
					context.write(word, newValue);
				} finally {
					;
				}
				
			}
		}
	}
	public static class CTokenizerMapper extends Mapper<Object, Text, Text, Text>{ //for the C operation
		//private static final IntWritable one =new IntWritable(1);
		private Text word =new Text();
		private Text newValue=new Text();
		public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
			//StringTokenizer itr=new StringTokenizer(value.toString());
			HashMap<String, String> stateList=new HashMap<>();
			String[] lines=value.toString().split("\n");
			boolean proper=true; //make sure this is the right file
			for (String line : lines) {
				if (line.length()<3) {
					continue;
				}
				String[] fields=line.split(",");
				if (!(fields.length==1) && (fields.length!=10 || (fields.length<6 || (fields[5].length()==0 || (fields[5].charAt(0)>='0' && fields[5].charAt(0)<='9'))))) { //the 5th element in the userdata file's rows is state, which is non-numeric
					proper=false;
					break; //do not go forward with this document.
				}
				if (fields.length==10 && fields[5].length()>1) {
					;
				} else {
					continue; //skip if not a line or not in New York
				}
				boolean res=stateList.containsKey(fields[5]);
				if (res==true) { //if was already in there, the above operation returns true
					int get=getNum(stateList.get(fields[5]).split("\t")[1]); //the split is to make sure the code works even if there's a number in the state's name.
					stateList.replace(fields[5], fields[5]+"\t"+(get+1)); 
				} else {
					stateList.put(fields[5], fields[5]+"\t"+1);
				}
				
			}
			if (proper) {
			Collection<String> nameNumbers=stateList.values();
			for (String nameNumber : nameNumbers) {
				String[] value1=nameNumber.split("\t"); 
				word.set(value1[0]); //select state
				newValue.set(value1[1]); //select the count.
				try {
					context.write(word, newValue);
				} finally {
					;
				}
			}
			}
		}
	}
	public static class DTokenizerMapper extends Mapper<Object, Text, Text, Text>{ //for the C operation
		//private static final IntWritable one =new IntWritable(1);
		private Text word =new Text();
		private Text newValue=new Text();
		public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
			//StringTokenizer itr=new StringTokenizer(value.toString());
			HashMap<String, String> stateList=new HashMap<>();
			String[] lines=value.toString().split("\n");
			boolean proper=true; //make sure this is the right file
			for (String line : lines) {
				if (line.length()<3) {
					continue;
				}
				String[] fields=line.split(",");
				if (!(fields.length==1) && (fields.length!=10 || (fields.length<6 || (fields[5].length()==0 || (fields[5].charAt(0)>='0' && fields[5].charAt(0)<='9'))))) { //the 5th element in the userdata file's rows is state, which is non-numeric
					proper=false;
					break; //do not go forward with this document.
				}
				if (fields.length==10 && fields[5].length()>1 && getNum(fields[9].split("/")[2])>=1970) {
					;
				} else {
					continue; //skip if not a line or not in New York
				}
				boolean res=stateList.containsKey(fields[5]);
				if (res==true) { //if was already in there, the above operation returns true
					int get=getNum(stateList.get(fields[5]).split("\t")[1]); //the split is to make sure the code works even if there's a number in the state's name.
					stateList.replace(fields[5], fields[5]+"\t"+(get+1)); 
				} else {
					stateList.put(fields[5], fields[5]+"\t"+1);
				}
				
			}
			if (proper) {
				Collection<String> nameNumbers=stateList.values();
				for (String nameNumber : nameNumbers) {
					String[] value1=nameNumber.split("\t"); 
					word.set(value1[0]); //select state
					newValue.set(value1[1]); //select the count.
					try {
						context.write(word, newValue);
					} finally {
						;
					}
				}
			}
		}
	}
	public static class ETokenizerMapper extends Mapper<Object, Text, Text, Text>{ //for the C operation
		//private static final IntWritable one =new IntWritable(1);
		private Text word =new Text();
		private Text newValue=new Text();
		public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
			//StringTokenizer itr=new StringTokenizer(value.toString());
			String[] lines=value.toString().split("\n");
			boolean proper=true; //make sure this is the right file
			//assume we are looking at userdata until it is clear that we are looking at friends data (when proper==false)
			for (String line : lines) {
				if (line.length()<3) {
					continue;
				}
				String[] fields=line.split(",");
				if (!(fields.length==1) && (fields.length!=10 || (fields.length<6 || (fields[5].length()==0 || (fields[5].charAt(0)>='0' && fields[5].charAt(0)<='9'))))) { //the 5th element in the userdata file's rows is state, which is non-numeric
					proper=false;
					break; //do not go forward with this document.
				}
				if (fields.length==10 && fields[0].length()>0) {
					;
				} else {
					continue; //skip if not a line or not in New York
				}
				try {
					word.set(fields[0]); //the key is the userid to match with thus from the friends file
					newValue.set(fields[1]+","+fields[4]); //first name and city name
					context.write(word, newValue);
				} finally {
					;
				}
			}
			if (!proper) { //we are in the friends file, and we can just count up the number of friends.
				for (String line : lines) {
					if (line.length()<3) {
						continue;
					}
					ArrayList<Double> friends=splitNum(line);
					try {
						word.set(""+friends.get(0).intValue()); //the userid is the first number
						newValue.set(""+(friends.size()-1)); //the first number is the userid of the person, the latter are that person's friends.
						context.write(word, newValue);
					} finally {
						;
					}
				}
			}
		}
	}

	public static class IntSumReducer extends Reducer<Text, Text, Text, Text> { //For task A, B
		//private IntWritable result=new IntWritable();
		private Text result=new Text();
		public void reduce(Text key1, Iterable<Text> valuesOrig, Context context) throws IOException, InterruptedException {
			int pieces=0;
			for (Text dividecomma : valuesOrig) {
				pieces++;
				String[] firstcity=dividecomma.toString().split(",");
				if (pieces==1 && firstcity.length==2 && firstcity[0].length()>1 && firstcity[1].length()>1) {
					try {
						String resultStr=""+firstcity[0]+"\t"+firstcity[1];
						//resultStr=resultStr+">";
						result.set(resultStr);
						context.write(key1, result);
					} finally {
						;
					}
					
				} else if (pieces==1) {
					pieces=0;
				}
			}
		}
	}
	public static class CIntSumReducer extends Reducer<Text, Text, Text, Text> { //For task C, D
		//private IntWritable result=new IntWritable();
		private Text result=new Text();
		public void reduce(Text key1, Iterable<Text> valuesOrig, Context context) throws IOException, InterruptedException {
			int pieces=0;
			for (Text dividecomma : valuesOrig) {
				pieces+=getNum(dividecomma.toString()); //this is COUNT(*)
			}
					try {
						String resultStr=""+pieces;
						//resultStr=resultStr+">";
						result.set(resultStr);
						context.write(key1, result);
					} finally {
						;
					}
					
		}
	}
	public static class EIntSumReducer extends Reducer<Text, Text, Text, Text> { //For task E
		//private IntWritable result=new IntWritable();
		private Text result=new Text();
		public void reduce(Text key1, Iterable<Text> valuesOrig, Context context) throws IOException, InterruptedException {
			int pieces=0;
			String resultStr="";
			for (Text dividecomma : valuesOrig) {
				String line =dividecomma.toString();
				if (line.contains(",")) { //first name, city name
					resultStr=line;
				} else { //number of friends
					pieces=getNum(line);
				}
			}
			resultStr+=","+pieces; //make sure number of friends comes after fname, city
			try {
				result.set(resultStr);
				context.write(key1, result);
			} finally {
				;
			}
		}
	}
	public static void main(String[] args) throws Exception {
		Configuration conf=new Configuration();
		Job job=Job.getInstance(conf, "RelationalFriends");
		job.setJarByClass(RelationalFriends.class);
		if (args[2].charAt(0)=='A') {
			job.setMapperClass(TokenizerMapper.class);
			//job.setCombinerClass(IntSumReducer.class);
			job.setReducerClass(IntSumReducer.class);
			job.setOutputKeyClass(Text.class);
			job.setOutputValueClass(Text.class);
			for (String arg : args) System.out.printf("%s\t", arg);
			System.out.println(" ");
			FileInputFormat.addInputPath(job, new Path(args[0]));
			FileOutputFormat.setOutputPath(job, new Path(args[1]));
			System.exit(job.waitForCompletion(true)? 0 : 1);
		} else if (args[2].charAt(0)=='B') {
			job.setMapperClass(BTokenizerMapper.class);
			//job.setCombinerClass(IntSumReducer.class);
			job.setReducerClass(IntSumReducer.class);
			job.setOutputKeyClass(Text.class);
			job.setOutputValueClass(Text.class);
			for (String arg : args) System.out.printf("%s\t", arg);
			System.out.println(" ");
			FileInputFormat.addInputPath(job, new Path(args[0]));
			FileOutputFormat.setOutputPath(job, new Path(args[1]));
			System.exit(job.waitForCompletion(true)? 0 : 1);
		} else if (args[2].charAt(0)=='C') {
			job.setMapperClass(CTokenizerMapper.class);
			job.setCombinerClass(CIntSumReducer.class); //this can be used if there are multiple files with userdata
			job.setReducerClass(CIntSumReducer.class);
			job.setOutputKeyClass(Text.class);
			job.setOutputValueClass(Text.class);
			for (String arg : args) System.out.printf("%s\t", arg);
			System.out.println(" ");
			FileInputFormat.addInputPath(job, new Path(args[0]));
			FileOutputFormat.setOutputPath(job, new Path(args[1]));
			System.exit(job.waitForCompletion(true)? 0 : 1);
		} else if (args[2].charAt(0)=='D') {
			job.setMapperClass(DTokenizerMapper.class);
			job.setCombinerClass(CIntSumReducer.class); 
			job.setReducerClass(CIntSumReducer.class);
			job.setOutputKeyClass(Text.class);
			job.setOutputValueClass(Text.class);
			for (String arg : args) System.out.printf("%s\t", arg);
			System.out.println(" ");
			FileInputFormat.addInputPath(job, new Path(args[0]));
			FileOutputFormat.setOutputPath(job, new Path(args[1]));
			System.exit(job.waitForCompletion(true)? 0 : 1);
		} else if (args[2].charAt(0)=='E') {
			job.setMapperClass(ETokenizerMapper.class);
			//job.setCombinerClass(EIntSumReducer.class); 
			job.setReducerClass(EIntSumReducer.class);
			job.setOutputKeyClass(Text.class);
			job.setOutputValueClass(Text.class);
			for (String arg : args) System.out.printf("%s\t", arg);
			System.out.println(" ");
			FileInputFormat.addInputPath(job, new Path(args[0]));
			FileOutputFormat.setOutputPath(job, new Path(args[1]));
			System.exit(job.waitForCompletion(true)? 0 : 1);
			
		}
	}
}
