#!/bin/bash
#Evan Nibbe
#March 31, 2021
#Relational.sh
#This program requires that you have already put RelationalFriends.java into the current directory
#and have already run the following code:
#ssh localhost
#start-all.sh to start the hadoop environment
#hdfs dfs -mkdir inputRelational
#hdfs dfs -put userdata.txt inputRelational/userdata.txt
#hdfs dfs -put soc-LiveJournal1Adj.txt inputRelational/
CHOICE="I"
PROBLEM="I" #is black until the correct thing is given.
#test returns true when the inner item is not null if there is one item.
while [ $PROBLEM ]; do #[ [ $CHOICE != "A" ] && [ [ $CHOICE != "B" ] && [ $CHOICE != "C" ] ] ] && [ [ $CHOICE != "D" ] && [ $CHOICE != "E" ] ] ]; do

echo "Make your selection of what kind of relational operation you want
A 	SELECT userid, firstname, city FROM userdata
B 	SELECT userid, firstname, city FROM userdata WHERE state equals New York
C	SELECT state, COUNT FROM userdata GROUP BY state
D	SELECT state, COUNT FROM userdata WHERE YEAR dateOfBirth is greater than or equal to 1970 GROUP BY state
E	SELECT userid, firstname, city, number of friends from the join on userid w.r.t. soc-LiveJournal1Adj.txt"
read CHOICE
echo "$CHOICE"
if [ $CHOICE == "A" ]; then PROBLEM=; fi
if [ $CHOICE == "B" ]; then PROBLEM=; fi
if [ $CHOICE == "C" ]; then PROBLEM=; fi
if [ $CHOICE == "D" ]; then PROBLEM=; fi
if [ $CHOICE == "E" ]; then PROBLEM=; fi

done

hadoop com.sun.tools.javac.Main RelationalFriends.java
jar cf RelationalFriends.jar RelationalFriends*.class
hdfs dfs -rm RelationalFriends.jar
hdfs dfs -rm -f -R outputRelational
hdfs dfs -put RelationalFriends.jar
hadoop jar RelationalFriends.jar RelationalFriends inputRelational outputRelational $CHOICE
