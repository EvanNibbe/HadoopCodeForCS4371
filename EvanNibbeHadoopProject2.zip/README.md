#!/bin/bash
#Evan Nibbe
#Project 2
#Introduction to Big Data Analytics CS 4371
#The project is in 3 main folders labelled for each problem being solved.
#correctProblem1, correctProblem2, and correctProblem3
#Within the first 2 of those is a directory called "output" which has a file called "console.out" which has the messages the program returned to console when run in isolation.
#The correctProblem3 directory has 5 subfolders of the style printf("option%coutputFiles", task_letter), which have the respective outputs that can be expected for
#running the jar file in Hadoop with the last command line argument being task_letter as an element of {A, B, C, D, E}.
#This README.md file itself can be executed provided that the hadoop system is running with the following in a 1st level directory structure: 
#drwxr-xr-x   - $USER supergroup          0 2021-03-26 14:25 inputMutualFriends
#-rw-r--r--   1 $USER supergroup    4106186 2021-03-21 22:01 inputMutualFriends/soc-LiveJournal1Adj.txt
#drwxr-xr-x   - $USER supergroup          0 2021-03-31 15:44 inputRelational
#-rw-r--r--   1 $USER supergroup    4106186 2021-03-31 15:34 inputRelational/soc-LiveJournal1Adj.txt
#-rw-r--r--   1 $USER supergroup    4342468 2021-03-31 15:42 inputRelational/userdata.txt
#(This can be checked with:
#hdfs dfs -ls -R
#)
#The files in this submission are (in a tree listing):
# README.md
#./correctProblem1:
# callMutualFriends.sh  'MutualFriends$IntSumReducer.class'  'MutualFriends$TokenizerMapper.class'   MutualFriends.class   MutualFriends.jar   MutualFriends.java   output   outputMutualFriends

#./correctProblem1/output:
#console.out  outputMutualFriends

#./correctProblem1/output/outputMutualFriends:
#part-r-00000  _SUCCESS

#./correctProblem1/outputMutualFriends:
#part-r-00000  _SUCCESS

#./correctProblem2:
#'AvgAndVarianceFriends$IntSumReducer.class'  'AvgAndVarianceFriends$TokenizerMapper.class'   AvgAndVarianceFriends.class   AvgAndVarianceFriends.jar   AvgAndVarianceFriends.java   callAvgAndVariance.sh   output   outputAvgAndVariance

#./correctProblem2/output:
#console.out  outputAvgAndVariance

#./correctProblem2/output/outputAvgAndVariance:
#part-r-00000  _SUCCESS

#./correctProblem2/outputAvgAndVariance:
#part-r-00000  _SUCCESS

#./correctProblem3:
# optionAoutputFiles   optionDoutputFiles  'RelationalFriends$BTokenizerMapper.class'  'RelationalFriends$DTokenizerMapper.class'  'RelationalFriends$IntSumReducer.class'     RelationalFriends.jar
# optionBoutputFiles   optionEoutputFiles  'RelationalFriends$CIntSumReducer.class'    'RelationalFriends$EIntSumReducer.class'    'RelationalFriends$TokenizerMapper.class'   RelationalFriends.java
# optionCoutputFiles   outputRelational    'RelationalFriends$CTokenizerMapper.class'  'RelationalFriends$ETokenizerMapper.class'   RelationalFriends.class                    Relational.sh

#./correctProblem3/optionAoutputFiles:
#console.out  outputRelational

#./correctProblem3/optionAoutputFiles/outputRelational:
#part-r-00000  _SUCCESS

#./correctProblem3/optionBoutputFiles:
#console.out  outputRelational

#./correctProblem3/optionBoutputFiles/outputRelational:
#part-r-00000  _SUCCESS

#./correctProblem3/optionCoutputFiles:
#console.out  outputRelational

#./correctProblem3/optionCoutputFiles/outputRelational:
#part-r-00000  _SUCCESS

#./correctProblem3/optionDoutputFiles:
#console.out  outputRelational

#./correctProblem3/optionDoutputFiles/outputRelational:
#outputRelational  part-r-00000  _SUCCESS

#./correctProblem3/optionDoutputFiles/outputRelational/outputRelational:
#part-r-00000  _SUCCESS

#./correctProblem3/optionEoutputFiles:
#console.out  outputRelational

#./correctProblem3/optionEoutputFiles/outputRelational:
#part-r-00000  _SUCCESS

#./correctProblem3/outputRelational:
#part-r-00000  _SUCCESS

#if you go within the correctProblem1 folder and type (within the hadoop environment with the soc-LiveJournal1Adj.txt inside inputMutualFriends ):
cd correctProblem1
./callMutualFriends.sh
#Then it will compile from the MutualFriends.java file, make sure that the output will go to an empty directory, and run the program
#To make sure the output is correct, you can run
rm -fdR outputMutualFriends
hdfs dfs -get outputMutualFriends
nano outputMutualFriends/part-r-00000
#Then to test my solution to the second problem:
cd ../correctProblem2
./callAvgAndVariance.sh 
#This compiles from the AvgAndVarianceFriends.java program and runs the .jar program using the same assumption
#of including the soc-LiveJournal1Adj.txt inside inputMutualFriends
#To make sure the output is correct, you can run
rm -fdR outputAvgAndVariance
hdfs dfs -get outputAvgAndVariance
nano outputAvgAndVariance/part-r-00000
#To do a similar check for the output of my answer for problem 3, you will have to run the program 5 times, but an efficient (human-wise)
#way to check everything is to 
#1) Make sure that the hadoop folder inputRelational has soc-LiveJournal1Adj.txt and userdata.txt 
#2) run this README.md file.
cd ../correctProblem3
read -p "You will see the answer for Task A (press enter)"
echo "A" | ./Relational.sh
rm -fdR outputRelational
hdfs dfs -get outputRelational
nano outputRelational/part-r-00000
read -p "You will see the answer for Task B (press enter)"
echo "B" | ./Relational.sh
rm -fdR outputRelational
hdfs dfs -get outputRelational
nano outputRelational/part-r-00000
read -p "You will see the answer for Task C (press enter)"
echo "C" | ./Relational.sh
rm -fdR outputRelational
hdfs dfs -get outputRelational
nano outputRelational/part-r-00000
read -p "You will see the answer for Task D (press enter)"
echo "D" | ./Relational.sh
rm -fdR outputRelational
hdfs dfs -get outputRelational
nano outputRelational/part-r-00000
read -p "You will see the answer for Task E (press enter)"
echo "E" | ./Relational.sh
rm -fdR outputRelational
hdfs dfs -get outputRelational
nano outputRelational/part-r-00000
